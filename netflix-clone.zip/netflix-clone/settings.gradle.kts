rootProject.name = "netflix-clone"
